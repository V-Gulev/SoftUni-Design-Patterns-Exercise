package picking.entities.bag;

import java.util.Collection;

public interface Bag {

    Collection<String> getMushrooms();
}
